create database db1;

use db1;



create table book (Isbn_Number integer AUTO_INCREMENT, 
Book_Name varchar(50) Not Null,

 Author_Name varchar(50) Not Null,Edition integer, 
 check(Edition > 0),primary key(ISbn_Number));



insert into book(Book_Name, Author_Name, Edition) values 
( 'Dr. A.P.J. Abdul Kalam','My Journey','7');


insert into book(Book_Name, Author_Name, Edition) values 
( 'Dr. Bibek Debroy','Making of New India','2');


select * from book;



drop table book;