package book.dao;

import java.sql.Connection;
import java.sql.Statement;
import book.domain.Book;

public class BookOperations 
{
	Connection con;
	Statement stmt;
	int ret;
	
	public int insertBook(Book b)     //inserts a new book details
	{
		con = JdbcCon.createCon();
		stmt = JdbcCon.createStatement();
		ret = BookInnerOperations.insertBook(b, con);
		int y = BookInnerOperations.getIsbn(b, stmt);
		if(y != 0)
			System.out.println("Isbn Number generated for new insertion is : "+y);
		JdbcCon.closeStatement();
		JdbcCon.closeCon();
		return ret;
	}
		
	public  Book readBook(Book b)    //reads the particular book details using isbn
	{
		con = JdbcCon.createCon();
		stmt = JdbcCon.createStatement();
		Book b1 = null;
		if(BookInnerOperations.validateIsbn(b, stmt))
			b1 = BookInnerOperations.readBook(b, stmt);		   
		else
			System.out.println("Invalid Isbn_Number!!!.....");
		JdbcCon.closeStatement();
		JdbcCon.closeCon();
		return b1 ;
	}
		
	public int updateBook(Book b)  //updates new edition number using isbn
	{
		con = JdbcCon.createCon();
		stmt = JdbcCon.createStatement();
		
		if(BookInnerOperations.validateIsbn(b, stmt))
			ret = BookInnerOperations.updateBook(b, con);
		else
			System.out.println("Invalid Isbn_Number!!!.....");
		JdbcCon.closeStatement();
		JdbcCon.closeCon();
		return ret ;
	}
	
	public int deleteBook(Book b)   //deletes book details using isbn
	{
		con = JdbcCon.createCon();
		stmt = JdbcCon.createStatement();
		if(BookInnerOperations.validateIsbn(b,stmt))
			 ret = BookInnerOperations.deleteBook(b, con);
		else
			System.out.println("Invalid Isbn_Number!!!.....");
		JdbcCon.closeStatement();
		JdbcCon.closeCon();
		return ret ;
	}	
}