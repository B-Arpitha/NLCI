package book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import book.domain.Book;

public class BookInnerOperations 
{
	static PreparedStatement pt;
	static ResultSet rs;
	
	public static int insertBook(Book b, Connection con)     //inserts a new book details
	{
		int ret = 0;
		try 
		{
			pt = con.prepareStatement(SqlMapper.addBook);
			pt.setString(1 , b.getBookName());
			pt.setString(2 , b.getAuthorName());
			pt.setInt(3 , b.getEdition());
			ret = pt.executeUpdate();
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}	
		return ret;
	}
	
	public static int getIsbn(Book b, Statement stmt)     //gets Isbn of inserted 
	{
		int ret = 0;
		try 
		{
			rs = stmt.executeQuery
					("select * from book where Book_Name ='"+b.getBookName()+"' and Author_name ='"+b.getAuthorName()+"' and Edition ="+b.getEdition());
			while(rs.next()) 
			{
				ret = rs.getInt("Isbn_Number");
			}
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}	
		return ret;
	}
	
	public static boolean validateIsbn(Book b, Statement stmt)  //checks whether particular isbn is present in table
	{
		boolean bool = false;
		try 
		{
			rs = stmt.executeQuery(SqlMapper.fetchBook + b.getIsbnNumber());
			bool = rs.next();
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		return (bool);
	}
	
	public static Book readBook(Book b , Statement stmt)  //reads the particular book details using isbn
	{	
		try 
		{
			rs = stmt.executeQuery(SqlMapper.fetchBook + b.getIsbnNumber());
			while(rs.next()) 
			{
				b.setAuthorName(rs.getString("Author_Name"));
				b.setBookName(rs.getString("Book_Name"));
				b.setEdition(rs.getInt("Edition"));
				b.setIsbnNumber(rs.getInt("Isbn_Number"));
			}	
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		return b;
	}
	
	public static int updateBook(Book b, Connection con)  //updates new edition number using isbn
	{
		int ret = 0;
		try 
		{
			pt = con.prepareStatement(SqlMapper.updateBook);
			pt.setInt(1, b.getEdition());
			pt.setInt(2,b.getIsbnNumber());
			ret = pt.executeUpdate();
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		
		return ret;
	}
	
	public static int deleteBook(Book bp, Connection con)  //delete book details using isbn
	{
		int ret = 0;
		try
		{
			PreparedStatement pt = con.prepareStatement(SqlMapper.deleteBook);
			pt.setInt(1,bp.getIsbnNumber());
			ret = pt.executeUpdate();
		}
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		return ret;	
	}
}
