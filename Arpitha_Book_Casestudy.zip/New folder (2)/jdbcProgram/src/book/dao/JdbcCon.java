package book.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcCon 
{
	static Connection con = null;
	static Statement stmt = null;
	
	public static Connection createCon()  //Creates connection with mysql
	{		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1","root","1234");
			
		} 
		catch (ClassNotFoundException ex) 
		{
			ex.printStackTrace();  
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return con;  
	}
	
	public static void closeCon()  //closes connection with mysql
	{
		try
		{
			con.close();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
	}
	
	public static Statement createStatement()  //creates statement
	{
		try 
		{
			stmt= con.createStatement();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return stmt;
	}
	
	public static void closeStatement()  //closes statement
	{
		try 
		{
			con.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}		
	}
	

}
