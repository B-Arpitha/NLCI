package book.junit;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import book.dao.BookOperations;
import book.domain.Book;

class JunitTesting 
{
	BookOperations bj = new BookOperations();
	Book bp = new Book();
	
	@Test
	void testInsertTrue1()
	{
		bp.setBookName("The Rule Breakers");
		bp.setAuthorName("Preeti Shenoy");
		bp.setEdition(5);
		assertEquals(1,bj.insertBook(bp));	// This is properly executed returns success
	}

	@Test
	void testInsertFailure1()// This failure occurs because of null value for author_Name
	{
		bp.setBookName("Revolution 2020");
		bp.setAuthorName(null); // cannot be null
		bp.setEdition(4);
		assertEquals(1,bj.insertBook(bp));	
	}
	
	@Test
	void testInsertFailure2() // This failure occurs because of null value for author_Name
	{
		bp.setBookName(null);// cannot be null
		bp.setAuthorName("Chetan bhagat"); 
		bp.setEdition(4);
		assertEquals(1,bj.insertBook(bp));	
	}
	
	@Test
	void testInsertFailure3()  // This failure occurs because Edition should be greater than 0 
	{
		bp.setBookName("Revolution 2020");
		bp.setAuthorName("Chetan bhagat");
		bp.setEdition(0); //should be greater than 0 
		assertEquals(1,bj.insertBook(bp));
	}
	
}
